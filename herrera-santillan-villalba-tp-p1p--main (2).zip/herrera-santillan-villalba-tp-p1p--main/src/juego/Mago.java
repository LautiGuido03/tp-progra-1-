package juego;

import java.awt.Color;
import entorno.Entorno;

public class Mago {
    int x;
    int y;
    int ancho;
    int alto;
    int vida;
    int velocidad = 5;

    public Mago(int x, int y, int ancho, int alto, int vida) {
        this.x = x;
        this.y = y;
        this.ancho = ancho;
        this.alto = alto;
        this.vida = vida;
    }

    public void mover(Entorno entorno, int anchoPantalla, int altoPantalla, Menu menu) {
        if (entorno.estaPresionada(entorno.TECLA_IZQUIERDA)) {
            if (x - velocidad - ancho / 2 >= 0) {
                x -= velocidad;
            }
        }

        if (entorno.estaPresionada(entorno.TECLA_DERECHA)) {
            if (x + velocidad + ancho / 2 <= menu.getLimiteIzquierdo()) {
                x += velocidad;
            }
        }

        if (entorno.estaPresionada(entorno.TECLA_ARRIBA)) {
            if (y - velocidad - alto / 2 >= 0) {
                y -= velocidad;
            }
        }

        if (entorno.estaPresionada(entorno.TECLA_ABAJO)) {
            if (y + velocidad + alto / 2 <= altoPantalla) {
                y += velocidad;
            }
        }
    }

    public void dibujar(Entorno entorno) {
        entorno.dibujarRectangulo(x, y, ancho, alto, 0, Color.blue);
    }

    // Métodos getter para la posición y dimensiones
    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public int getAncho() {
        return this.ancho;
    }

    public int getAlto() {
        return this.alto;
    }
}
