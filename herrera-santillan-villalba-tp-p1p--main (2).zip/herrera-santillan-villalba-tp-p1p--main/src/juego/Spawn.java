package juego;

import java.util.Random;

public class Spawn {
    private Random random;
    private final int ALTO_MENU = 100;

    public Spawn() {
        this.random = new Random();
    }

    public murcielago CrearMurcielago() {
        int borde = random.nextInt(4); // 0=arriba, 1=derecha, 2=abajo, 3=izquierda
        int x = 0;
        int y = 0;

        if (borde == 0) {  // Borde superior
            x = random.nextInt(800); // Aparece entre 0 y 799 en el eje X
            y = -20;  // Aparece fuera de la pantalla por arriba
        } else if (borde == 1) {  // Borde derecho
            x = 800;  // Aparece fuera de la pantalla por la derecha
            y = random.nextInt(500) + ALTO_MENU;  // Aparece entre 100 y 600 en el eje Y
        } else if (borde == 2) {  // Borde inferior (abajo)
            x = random.nextInt(800);  // Aparece entre 0 y 799 en el eje X
            y = 600;  // Aparece fuera de la pantalla por abajo
        } else if (borde == 3) {  // Borde izquierdo
            x = -20;  // Aparece fuera de la pantalla por la izquierda
            y = random.nextInt(500) + ALTO_MENU;  // Aparece entre 100 y 600 en el eje Y
        }

        return new murcielago(x, y); // Crear y devolver el murciélago con las coordenadas aleatorias
    }
}
