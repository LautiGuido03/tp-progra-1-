package juego;

import java.awt.Color;

import entorno.Entorno;

public class Roca {
    private double x; 
    private double y;
    private double diametro;
    private Color color;

    public Roca(double x, double y){
        this.x = x; 
        this.y = y; 
        this.diametro = 50;
        this.color = Color.GRAY; // color de la piedra GRIS
        
    }
    
    public void dibujar (Entorno entorno) {
    	entorno.dibujarCirculo(x, y, diametro, color);
    	
    }
    
    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

}

