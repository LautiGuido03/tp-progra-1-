package juego;

import java.awt.Color;

import entorno.Entorno;

public class Menu {
    int alto; 
    int ancho; 
    int x; 
    int y; 

    public Menu(int x, int y, int ancho, int alto){
        this.x = x; 
        this.y = y; 
        this.ancho = ancho; 
        this.alto = alto; 
    }

    public void dibujar(Entorno entorno){
        entorno.dibujarRectangulo(x, y, ancho, alto, 0, Color.orange);
    }

    public int getLimiteIzquierdo(){
        return this.x - this.ancho / 2; 
    }
}
