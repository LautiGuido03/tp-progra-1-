package juego;

import java.awt.Color;
import entorno.Entorno;

public class murcielago {
    private int x;
    private int y;
    private int tamaño;
    private Color color;

    public murcielago(int x, int y) {
        this.x = x;
        this.y = y;
        this.tamaño = 30; // Tamaño del murciélago
        this.color = Color.MAGENTA; // El color por defecto del murciélago
    }

    // Mover el murciélago hacia las coordenadas del mago
    public void moverHacia(int objetivoX, int objetivoY) {
        int velocidad = 2;
        if (x < objetivoX) {
            x += velocidad;
        } else if (x > objetivoX) {
            x -= velocidad;
        }

        if (y < objetivoY) {
            y += velocidad;
        } else if (y > objetivoY) {
            y -= velocidad;
        }
    }

    // Dibujar el murciélago en la pantalla
    public void dibujar(Entorno entorno) {
        entorno.dibujarCirculo(x, y, tamaño, color);
    }

    // Verificar si el murciélago colisiona con el mago
    public boolean colisionaCon(int magoX, int magoY, int magoAncho) {
        return (x > magoX - magoAncho / 2 && x < magoX + magoAncho / 2) &&
               (y > magoY - magoAncho / 2 && y < magoY + magoAncho / 2);
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}
