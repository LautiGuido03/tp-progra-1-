package juego;

import java.awt.Color;
import entorno.Entorno;
import entorno.InterfaceJuego;
import java.util.ArrayList;

<<<<<<< HEAD
public class Juego extends InterfaceJuego
{
	// El objeto Entorno que controla el tiempo y otros
	private Entorno entorno;
	private Mago mago; 
	private Menu menu;  
	private Boton boton1; 
	private Boton boton2;  
	// Variables y métodos propios de cada grupo
	// ...
	private final int ANCHO_PANTALLA = 800; 
	private final int ALTO_PANTALLA = 600; 
	private final int ALTO_MENU = 100; 
	Juego()
	{
		// Inicializa el objeto entorno
		this.entorno = new Entorno(this, "Proyecto para TP", 800, 600);
		this.mago = new Mago(ANCHO_PANTALLA / 2, ALTO_MENU + 50, 40, 60, 3);  
		this.menu = new Menu(750, 300, 150, 600); 
		this.boton1 = new Boton(740, 100, 80, 40, "Fuego"); 
		this.boton2 = new Boton(740, 160, 80, 40, "Agua");   
		// Inicializar lo que haga falta para el juego
		// ...
=======
public class Juego extends InterfaceJuego {
    private Entorno entorno;
    private Mago mago;
    private Menu menu;
    private Spawn spawn;
    private ArrayList<murcielago> murcielagos;  // Lista para almacenar los murciélagos
    private Roca[] rocas;
>>>>>>> fa9b99b9df69586b392dc783ce10ea42ed72c9d4

    private final int ANCHO_PANTALLA = 800;
    private final int ALTO_PANTALLA = 600;
    private final int ALTO_MENU = 100;

<<<<<<< HEAD
	/**
	 * Durante el juego, el método tick() será ejecutado en cada instante y 
	 * por lo tanto es el método más importante de esta clase. Aquí se debe 
	 * actualizar el estado interno del juego para simular el paso del tiempo 
	 * (ver el enunciado del TP para mayor detalle).
	 */
	public void tick()
	{
		// Procesamiento de un instante de tiempo
		// ...
		mago.mover(entorno, ANCHO_PANTALLA, ALTO_PANTALLA, menu); //ALTO_MENU); 
		mago.dibujar(entorno); 
		menu.dibujar(entorno); 
		/*int mouseX = entorno.obtenerPosicionMouseX(); 
		int mouseY = entorno.obtenerPosicionMouseY(); 
		boolean clickDerecho = entorno.sePresiono(entorno.MOUSE_DERECHO); 	
		if(boton1.fuePresionado(mouseX, mouseY, clickDerecho)){
			boton1.setPresionado(true); 
			boton2.setPresionado(false); 
		} else if (boton2.fuePresionado(mouseX, mouseY, clickDerecho)) {
			boton2.setPresionado(true); 
			boton1.setPresionado(false); 
		}*/ 
		if(entorno.sePresiono('1')){
			boton1.setPresionado(true); 
			boton2.setPresionado(false); 
		} else if(entorno.sePresiono('2')){
			boton2.setPresionado(true); 
			boton1.setPresionado(false); 
		}
		boton1.dibujar(entorno); 
		boton2.dibujar(entorno);
	}
=======
    public Juego() {
        this.entorno = new Entorno(this, "Proyecto para TP", 800, 600);
        this.mago = new Mago(270, 330, 40, 60, 3);
        this.menu = new Menu(750, 300, 150, 600);
        this.spawn = new Spawn(); // Creamos la instancia de la clase Spawn
        this.murcielagos = new ArrayList<murcielago>(); // Inicializamos la lista de murciélagos
        this.entorno.iniciar(); // Inicializa el juego
        
        rocas = new Roca[5];

	     // Roca 0: Encima del mago 
	     rocas[0] = new Roca(335, 230); // (350 - 60 - 20). Roca arriba del mago sin superponer
>>>>>>> fa9b99b9df69586b392dc783ce10ea42ed72c9d4
	
	     // Roca 1: Esquina superior izquierda
	     rocas[1] = new Roca(120, 90);
	
	     // Roca 2: Esquina superior derecha 
	     rocas[2] = new Roca(650 - 100, 90); 
	
	     // Roca 3: Esquina inferior izquierda
	     rocas[3] = new Roca(120, 600 - 100); 
	
	     // Roca 4: Esquina inferior derecha 
	     rocas[4] = new Roca(650 - 90, 600 - 100);
        
    }

    public void tick() {
        // Si no hay más de 50 murciélagos, crea uno nuevo
        if (murcielagos.size() < 50) {
            murcielago nuevoMurcielago = spawn.CrearMurcielago();
            murcielagos.add(nuevoMurcielago);
        }

        // Mover y dibujar los murciélagos, y eliminar los que colisionan
        for (int i = 0; i < murcielagos.size(); i++) {
            murcielago m = murcielagos.get(i);
            m.moverHacia(mago.getX(), mago.getY());

            // Comprobar si el murciélago colisiona con el mago
            if (m.colisionaCon(mago.getX(), mago.getY(), mago.getAncho())) {
                murcielagos.remove(i); // Eliminar el murciélago que colisionó
                i--; // Ajustar el índice debido a la eliminación
                // Crear un nuevo murciélago tras la colisión
                murcielago nuevoMurcielago = spawn.CrearMurcielago();
                murcielagos.add(nuevoMurcielago);
            } else {
                m.dibujar(entorno); // Dibujar los murciélagos que no colisionaron
            }
        }

        // Mover y dibujar el mago y el menú
        mago.mover(entorno, ANCHO_PANTALLA, ALTO_PANTALLA, menu);
        mago.dibujar(entorno);
        menu.dibujar(entorno);
        
        for (int i = 0; i < rocas.length; i++) {
            rocas[i].dibujar(entorno);
        }

    }

    public static void main(String[] args) {
        Juego juego = new Juego();
    }
}
